---
name: "⚠️ General Support"
about: 'This repository is only for reporting bugs or problems. If you need help using Winter CMS, see: https://wintercms.com/support'
---

This repository is only for reporting bugs or problems. If you need support, please use the following options:

- Discord: https://discord.gg/D5MFSPH6Ux
- Stack Overflow: https://stackoverflow.com/questions/tagged/wintercms

Thanks!