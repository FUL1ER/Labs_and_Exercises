---
name: "🚨 Immediate Support"
about: 'I use Winter and it just broke! Help me!'
---

This repository is only for reporting reproducible bugs or problems. If you need support, please use the following options:

- Slack: https://discord.gg/D5MFSPH6Ux
- Stack Overflow: https://stackoverflow.com/questions/tagged/wintercms

If you rely on Winter CMS for your business consider purchasing a paid support plan! Send an email to wintercms@luketowers.ca to get started.

Thanks!