---
name: "📚 Documentation Issue"
about: 'For documentation issues, see: https://github.com/wintercms/docs/issues'
---

The Winter CMS documentation has its own dedicated repository. Please open your documentation-related issue at https://github.com/wintercms/docs/issues.

> **NOTE:** Since documentation issues are not reviewed very often, it's best to simply make a pull request to correct the issue you have found!**

Thanks!