/*
 * This is a bundle file, you can compile this by running
 *
 *     php artisan winter:util compile assets
 *
 * @see winter-min.js
 *

=require vendor/jquery.touchwipe.js
=require vendor/jquery.autoellipsis.js
=require vendor/jquery.waterfall.js
=require vendor/jquery.cookie.js
=require ../vendor/dropzone/dropzone.js
=require ../vendor/sweet-alert/sweet-alert.js
=require ../vendor/jcrop/js/jquery.Jcrop.js
=require ../../../system/assets/vendor/prettify/prettify.js
=require ../../widgets/mediamanager/assets/js/mediamanager-global.js

=require winter.lang.js
=require winter.alert.js
=require winter.scrollpad.js
=require winter.verticalmenu.js
=require winter.navbar.js
=require winter.sidenav.js
=require winter.scrollbar.js
=require winter.filelist.js
=require winter.layout.js
=require winter.sidepaneltab.js
=require winter.simplelist.js
=require winter.treelist.js
=require winter.sidenav-tree.js
=require winter.datetime.js

=require backend.js
*/
