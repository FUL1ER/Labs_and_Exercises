/*
 * This is a bundle file, you can compile this by running
 *
 *     php artisan winter:util compile assets
 *
 * @see build-plugins-min.js
 *

=require plugins/mediamanager.js
=require plugins/pagelinks.js
=require plugins/figures.js
=require richeditor.js

*/
