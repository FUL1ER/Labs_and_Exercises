View the changelog on the [meta repository](https://github.com/wintercms/meta/tree/master/release-notes)
